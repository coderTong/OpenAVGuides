//
//  CCNavigationController.m
//  IntelliDev
//
//  Created by chenchao on 16/4/28.
//  Copyright © 2016年 chenchao. All rights reserved.
//

#import "CCNavigationController.h"

@implementation CCNavigationController

- (id)init
{
    
    if ( self = [super init])
    {
        
    }
    return self;
}
- (BOOL)shouldAutorotate
{
    return NO;
}



@end
