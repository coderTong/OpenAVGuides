//
//  AppDelegate.h
//  TestH264
//
//  Created by codew on 8/31/19.
//  Copyright © 2019 fee. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

