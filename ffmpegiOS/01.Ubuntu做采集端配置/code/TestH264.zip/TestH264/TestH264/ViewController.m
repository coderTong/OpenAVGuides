//
//  ViewController.m
//  TestH264
//
//  Created by codew on 8/31/19.
//  Copyright © 2019 fee. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}


@end
