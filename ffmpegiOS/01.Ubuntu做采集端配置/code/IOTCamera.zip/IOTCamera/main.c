#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <pthread.h>
#include <errno.h>
#include <malloc.h>
#include <signal.h>
#include "socketserver.h"



 int main(int argc, char *argv[])
 {
    start_tcp_server();
 }
