//
//  DataStructDefine.h
//  IntelliDev
//
//  Created by chenchao on 16/4/29.
//  Copyright © 2016年 chenchao. All rights reserved.
//

#ifndef DataStructDefine_h
#define DataStructDefine_h

#define     INT8           unsigned char
#define     INT16          unsigned short
#define     INT32          unsigned int

#endif /* DataStructDefine_h */
